package com.virtusa;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.springframework.stereotype.Component;
@Component
public class ResponsePostFilter implements Filter {
	

 
	  private FilterConfig config = null;
	  public void doFilter(ServletRequest request, ServletResponse response,
	  FilterChain filterchain)throws IOException, ServletException{
	  filterchain.doFilter(request, response);
	  response.setContentType("text/html");
	  PrintWriter out = response.getWriter();
	  out.println("<b>Filter Received Your Message Successfully:</b>" + 
	  config.getInitParameter("details"));
	  }
	  public void destroy() { }
	  public void init(FilterConfig config) {
	  this.config = config;
	  
	}
}
