package com.virtusa;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.validation.Valid;

import java.io.IOException;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomerController {
	
	public static final Logger mylogger = Logger.getLogger(CustomerController.class.getName());
	
	@RequestMapping("/register")
	public String register(Model m) {
						
		m.addAttribute("cust",new Customer());
		
		return "registrationform";
	}
	
	@RequestMapping("/details")
	public String details(@Valid @ModelAttribute("cust") Customer c,BindingResult br) throws IOException, ServletException {
		
		if(c.getFirstName().isEmpty()) {
			throw new RuntimeException();
		}
	//	m.addAttribute("Customer", c);
		if(br.hasErrors())
		{
			return "registrationform";
		}
		
		if(c.getFirstName() != null)
			mylogger.info("FirstNAme  : "+c.getFirstName());
		return "details";
	}

}
