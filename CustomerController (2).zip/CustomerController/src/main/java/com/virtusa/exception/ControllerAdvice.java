package com.virtusa.exception;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

//@ControllerAdvice
@EnableWebMvc
public class ControllerAdvice {
	
	@ExceptionHandler(value=RuntimeException.class)
	public String exceptionHandler() {
		return "RuntimeException";
	}

}
