package com.virtusa;

import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostFilter;


public class Customer {
	@Autowired
	ResponsePostFilter responsePostFilter;
	
	@NotEmpty(message="req")
	private String firstName;
	@NotEmpty(message="req")
	private String lastName;
	private String email;
	private int mobile;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	@PostFilter ("firstName == Pooja")
	public String toString() {
		
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", mobile=" + mobile
				+ "]";
		
	}
	
	
	

}
