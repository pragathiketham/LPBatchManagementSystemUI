package com.manytoone;

public class EmployeeDao {

}
