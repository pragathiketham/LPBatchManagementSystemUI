package com.virtusa.otomany;

public class EmployeeDao {

}
