package com.manytomany;

public class QueDao {
	

}
